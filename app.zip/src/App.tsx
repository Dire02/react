import React from 'react';
import Login from "./pages/login_signUpPage/login";
import Home from "./pages/home/home";

function App() {


  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
